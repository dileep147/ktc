<?php

class ProjectConfig {

    public static $project_name = " - KTC POS - ";
    public static $address = " - KTC POS - ";
    public static $tel = " contact ";
    public static $address_arr = array(" - KTC POS - ", "Address 1", "Address 2", "Address 3", "Address 4");
    public static $tel_arr = array(" contact-1 ", " contact-2 ");
    public static $address_html = "<strong> - KTC POS - </strong> , <br/> Address,<br/>Address,<br/>Address. ";
    public static $tel_html = "<strong> Phone: </strong> contact ";

//    public static $modules = array(
//        "user" => "User",
//        "privilege" => "Privilege",
//        "designation" => "Designation",
//        "target" => "Target",
//        "category" => "Category",
//        "product" => "Product",
//        "batch" => "Batch",
//        "material" => "Material",
//        "production_plan" => "Production Plan",
//        "production" => "Production",
//        "supplier" => "Supplier",
//        "customer" => "Customer",
//        "route" => "Route",
//        "product_po" => "Product PO",
//        "material_po" => "Material PO",
//        "product_po" => "Product GRN",
//        "material_po" => "Material GRN",
//        "invoice" => "Invoice",
//        "payment" => "Payment",
//        "return" => "Return",
//        "deliverer" => "Deliverer",
//        "deliverer_inventory" => "Deliverer Inventory"
//    );
}
