<footer>
    <div class="pull-right">
        <?php echo ProjectConfig::$project_name; ?> - Control panel by <a href="https://aitlab.lk" target="_blank">AIT</a>
    </div>
    <div class="clearfix"></div>
</footer>