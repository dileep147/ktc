<?php
require_once __DIR__.'/../util/initialize.php';

class UserStatus extends DatabaseObject{
    protected static $table_name="user_status";
    protected static $db_fields=array();
    protected static $db_fk=array();
    
//    public $id;
//    public $name;
}

?>