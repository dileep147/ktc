<?php
require_once __DIR__.'/../util/initialize.php';

class PackageCategory extends DatabaseObject{
    protected static $table_name="package_category";
    protected static $db_fields=array(); 
    protected static $db_fk=array();
    
    
//    public $id;
//    public $name;
}

?>